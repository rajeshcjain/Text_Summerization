from pyrouge import Rouge155
r = Rouge155()
# set directories
r.system_dir = "/Users/rajeshjain/projects/GreatLearnings/assignments/residency/gurgaonbatch-rajeshcjain/CapstonProject/pretrained_model/decode_val_400maxenc_4beam_35mindec_120maxdec_ckpt-238410/decoded/"
r.model_dir = "/Users/rajeshjain/projects/GreatLearnings/assignments/residency/gurgaonbatch-rajeshcjain/CapstonProject/pretrained_model/decode_val_400maxenc_4beam_35mindec_120maxdec_ckpt-238410/reference/"
 
# define the patterns
r.system_filename_pattern = "(\d+)_decoded.txt"
r.model_filename_pattern = "#ID#_reference.txt"
 
# use default parameters to run the evaluation
output = r.convert_and_evaluate()
print(output)
output_dict = r.output_to_dict(output)
